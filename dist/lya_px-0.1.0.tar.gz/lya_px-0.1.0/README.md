# Lya_PxEC
Lyman alpha forest cross power spectrum estimator code 

